package jhb.board.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jhb.mapper.BoardDaoInter;

@Service
@Transactional
public class BoardDao  {

	@Autowired
	private BoardDaoInter mapper;
	
    
    public int getTotalCount() {
        // TODO Auto-generated method stub
        int n = mapper.getTotalCount();
        return n;
    }

   
    public void insertBoard(BoardDto dto) {
    	mapper.insertBoard(dto);

    }

   
    public List<BoardDto> getList(int start, int end) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("start", start);
        map.put("end", end);
        return mapper.getList(map);

    }

   
    public void updateReadcount(int num) {
    	mapper.updateReadcount(num);

    }

    
    public BoardDto getData(int num) {
        // TODO Auto-generated method stub
        return mapper.getData(num);
    }

  
    public void boardDelete(int num) {
        // TODO Auto-generated method stub
    	mapper.boardDelete(num);
    }

   
    public void boardUpdate(BoardDto dto) {
    	mapper.boardDelete(dto.getNum());

    }


}
