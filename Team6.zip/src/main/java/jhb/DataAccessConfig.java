package jhb;

public class DataAccessConfig {

}
