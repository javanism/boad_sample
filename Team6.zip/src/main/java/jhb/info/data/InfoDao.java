package jhb.info.data;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jhb.mapper.GuestDaoInter;
import jhb.mapper.InfoDaoInter;

@Service
@Transactional
public class InfoDao {

	
	@Autowired
	private InfoDaoInter mapper;
	
    
    public List<InfoDto> getAllDatas() {
        // TODO Auto-generated method stub
        return mapper.getAllDatas();
    }

    
    public void insertInfo(InfoDto dto) {
        // TODO Auto-generated method stub
    	mapper.insertInfo(dto);
    }

}
