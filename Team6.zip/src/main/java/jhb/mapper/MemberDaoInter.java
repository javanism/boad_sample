package jhb.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import jhb.member.data.MemberDto;

@Repository
@Mapper
public interface MemberDaoInter {
    public List<MemberDto> getAllDatas();

    public void insertMember(MemberDto dto);

    public MemberDto getData(String num);

    public void updateMember(MemberDto dto);

    public void deleteMember(MemberDto dto);

    //아이디 비번 체크
    public boolean isLogin(HashMap<String, String> map);

    //네임얻기 
    public String getName(String id);
}
