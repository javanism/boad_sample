package jhb.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import jhb.guest.data.GuestDto;
@Repository
@Mapper
public interface GuestDaoInter {
    public void insertGuest(GuestDto dto);

    public List<GuestDto> getList(Map<String, Integer> map);

    public int getTotalCount();

    public void deleteGuest(int num);

    public GuestDto getData(int num);


}
