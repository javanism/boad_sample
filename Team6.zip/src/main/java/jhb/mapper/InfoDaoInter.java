package jhb.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import jhb.info.data.InfoDto;

@Repository
@Mapper
public interface InfoDaoInter {
    public List<InfoDto> getAllDatas();

    public void insertInfo(InfoDto dto);
}
