package jhb.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import jhb.board.data.BoardDto;

@Repository
@Mapper
public interface BoardDaoInter {
    public int getTotalCount();

    public void insertBoard(BoardDto dto);

    public List<BoardDto> getList(Map<String, Integer> map);

    public void updateReadcount(int num);

    public BoardDto getData(int num);

    public void boardDelete(int num);

    public void boardUpdate(BoardDto dto);


}
