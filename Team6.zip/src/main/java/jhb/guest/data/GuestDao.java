package jhb.guest.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;


import jhb.mapper.GuestDaoInter;

@Service
@Transactional
public class GuestDao {

	@Autowired
	private GuestDaoInter mapper;
	
  
    public void insertGuest(GuestDto dto) {
    	mapper.insertGuest(dto);

    }

    
    public List<GuestDto> getList(int start, int end) {

        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("start", start);
        map.put("end", end);
        return mapper.getList(map);
    }

    
    public int getTotalCount() {
        // TODO Auto-generated method stub
        return mapper.getTotalCount();
    }

   
    public void deleteGuest(int num) {
    	mapper.deleteGuest(num);

    }

    
    public GuestDto getData(int num) {
        // TODO Auto-generated method stub
        return mapper.getData(num);
    }


}
