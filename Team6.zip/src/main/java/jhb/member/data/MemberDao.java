package jhb.member.data;

import java.util.HashMap;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jhb.mapper.InfoDaoInter;
import jhb.mapper.MemberDaoInter;


@Service
@Transactional
public class MemberDao  {

	@Autowired
	private MemberDaoInter mapper;
	
    
    public List<MemberDto> getAllDatas() {
        // TODO Auto-generated method stub
        return mapper.getAllDatas();
    }

    
    public void insertMember(MemberDto dto) {
        // TODO Auto-generated method stub
    	mapper.insertMember(dto);
    }

    
    public MemberDto getData(String num) {
        // TODO Auto-generated method stub
        return mapper.getData(num);
    }

    
    public void updateMember(MemberDto dto) {
        // TODO Auto-generated method stub
    	mapper.updateMember(dto);
    }

    
    public void deleteMember(MemberDto dto) {
        // TODO Auto-generated method stub
    	mapper.deleteMember(dto);
    }

    
    public boolean isLogin(String id, String pass) {
        // TODO Auto-generated method stub
        HashMap<String, String> map = new HashMap<String, String>(); //해쉬 맵 사용
        map.put("id", id);
        map.put("pass", pass);
        boolean b = mapper.isLogin(map);
        return b; 
    }

    
    public String getName(String id) {
        // TODO Auto-generated method stub
        String name = mapper.getName(id);

        return name;
    }

}
