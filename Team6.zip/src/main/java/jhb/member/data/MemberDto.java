package jhb.member.data;

import java.sql.Timestamp;

public class MemberDto {
    private String num;
    private String name;
    private String id;
    private String pass;
    private Timestamp gaipday;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Timestamp getGaipday() {
        return gaipday;
    }

    public void setGaipday(Timestamp gaipday) {
        this.gaipday = gaipday;
    }
}
