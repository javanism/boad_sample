package jhb.fabric;


import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallet.Identity;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdk.security.CryptoSuiteFactory;
import org.hyperledger.fabric_ca.sdk.EnrollmentRequest;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FabricService {
	
	public void enrollAdmin() throws Exception {

		// Create a CA client for interacting with the CA.
		Properties props = new Properties();
		props.put("pemFile",
			"/root/HLF/fabric-samples/basic-network/crypto-config/peerOrganizations/org1.example.com/ca/ca.org1.example.com-cert.pem");
		props.put("allowAllHostNames", "true");
		HFCAClient caClient = HFCAClient.createNewInstance("http://localhost:7054", props);
		CryptoSuite cryptoSuite = CryptoSuiteFactory.getDefault().getCryptoSuite();
		caClient.setCryptoSuite(cryptoSuite);

		// Create a wallet for managing identities
		Wallet wallet = Wallet.createFileSystemWallet(Paths.get("wallet"));

		// Check to see if we've already enrolled the admin user.
		boolean adminExists = wallet.exists("admin");
        if (adminExists) {
            System.out.println("An identity for the admin user \"admin\" already exists in the wallet");
            return;
        }

        // Enroll the admin user, and import the new identity into the wallet.
        final EnrollmentRequest enrollmentRequestTLS = new EnrollmentRequest();
        enrollmentRequestTLS.addHost("localhost");
        //enrollmentRequestTLS.setProfile("tls");
        Enrollment enrollment = caClient.enroll("admin", "adminpw", enrollmentRequestTLS);
        Identity user = Identity.createIdentity("Org1MSP", enrollment.getCert(), enrollment.getKey());
        wallet.put("admin", user);
		System.out.println("Successfully enrolled user \"admin\" and imported it into the wallet");
	}
	
	
	public  String queryAllGoods() throws Exception {
		// Load a file system based wallet for managing identities.
				Path walletPath = Paths.get("C:\\Windows\\System32\\wallet");
				Wallet wallet = Wallet.createFileSystemWallet(walletPath);

				// load a CCP
				Path networkConfigPath = Paths.get("C:\\Windows\\System32\\a", "connection.json");

				Gateway.Builder builder = Gateway.createBuilder();
				builder.identity(wallet, "user1").networkConfig(networkConfigPath).discovery(false);

				// create a gateway connection
				try (Gateway gateway = builder.connect()) {

					// get the network and contract
					Network network = gateway.getNetwork("mychannel");
					Contract contract = network.getContract("goods");

					byte[] result;

					result = contract.evaluateTransaction("queryAllGoods");
					return new String(result);
				}

	}


	
	@GetMapping("/fabric")
	public @ResponseBody Map<String,Object> fabric() {
		System.out.println("fabric 요청 처리...");
		Map<String ,Object> map=new HashMap<>();
		try {
			map.put("result",queryAllGoods());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return map;
	}

}


