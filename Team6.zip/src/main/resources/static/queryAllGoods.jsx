var {Component} = React;
 
class Goods extends Component{   
   state={
    result:null
   }   

    queryAllGoods=()=>{
        const data={            
        }
        alert(JSON.stringify(data));

        axios.get('fabric',data)
        .then((res)=>{            
            alert(res.data.result);
            this.setState({
            	result:res.data.result
            });
            console.log(res.data.result);
        })
        .catch((err)=>{
            console.log(err);
        });
    }
 
    render(){
        return(
            <div>
                <h2>명품조회</h2>   
                
                
                
                <button onClick={this.queryAllGoods}>조회</button>
                <hr/>
                <br/>
       			{this.state.result}
            </div>
        );
    }
}
 
ReactDOM.render(
    (<Goods/>)
    ,document.getElementById("here")
);
 
