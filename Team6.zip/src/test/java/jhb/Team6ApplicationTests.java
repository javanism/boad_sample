package jhb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
